﻿using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Data;

namespace CRUD_WITH_ADO.Models
{
    public class EmployeeDataAccess
    {
        DBConnection Dbconnection;
        public EmployeeDataAccess()
        {
            Dbconnection = new DBConnection();
        }
        public List<Employees> GetEmployees()
        {
            string Sp = "SP_Employee";
            SqlCommand sql = new SqlCommand(Sp, Dbconnection.Connection);
            sql.CommandType = CommandType.StoredProcedure;
            sql.Parameters.AddWithValue("@action", "SELECT_JOIN");
            if (Dbconnection.Connection.State == ConnectionState.Closed)
            {
                Dbconnection.Connection.Open();
            }
            SqlDataReader dr = sql.ExecuteReader();
            List<Employees> employees = new List<Employees>();
            while (dr.Read())
            {
                Employees Emp = new Employees();
                Emp.Id = (int)dr["Id"];
                Emp.Name = dr["Name"].ToString();
                Emp.Email = dr["Email"].ToString();              
                Emp.Gender = dr["Gender"].ToString();
                Emp.Mobile = dr["Mobile"].ToString();
               // Emp.Department_Id = (int)dr["Department_Id"];
                employees.Add(Emp);
            }
            Dbconnection.Connection.Close();
            return employees;

        }
    }
}
