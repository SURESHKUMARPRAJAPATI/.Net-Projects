﻿namespace CRUD_WITH_ADO.Models
{
    public class Dbconfig
    {
        public static string ConnectionStr { get; set; }

    }
}
