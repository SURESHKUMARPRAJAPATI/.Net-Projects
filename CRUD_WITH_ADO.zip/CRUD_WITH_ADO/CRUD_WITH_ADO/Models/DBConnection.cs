﻿using Microsoft.Data.SqlClient;
namespace CRUD_WITH_ADO.Models
{
    public class DBConnection
    {
       
        public SqlConnection Connection;
        public DBConnection()
        {
            Connection = new SqlConnection
                (Dbconfig.ConnectionStr);
        }

        //public SqlConnection SqLConnection { get; set; }
    }
}
