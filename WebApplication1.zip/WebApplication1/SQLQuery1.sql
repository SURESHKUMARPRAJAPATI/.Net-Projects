﻿select * from Locations;
insert into Locations values
('Mumbai','This is best place'),
('Delhi','This is best place'),
('Meerut','This is best place'),
('Noida','This is best place'),
('Rampur','This is best place'),
('Amroha','This is best place'),
('Moradabad','This is best place'),
('Greater Noida','This is best place'),
('Noida','This is best place')

insert into Customers values
('Ajay Kumar', 'ajaykumar43@gmail.com','9857475745','1'),
('Vijay Kumar', 'vijaykumar43@gmail.com','9067656789','2'),
('Sunil Kumar', 'ajaykumar43@gmail.com','9765543423','1'),
('Monu Kumar', 'monukumar43@gmail.com','9857475545','5'),
('Ajay Kumar', 'ajaykumar43@gmail.com','9856575745','10'),
('Rakesh Kumar', 'rakeshkumar43@gmail.com','989475745','2'),
('Ravi Kumar', 'ravikumar43@gmail.com','9857434745','3'),
('Ajay Kumar', 'ajaykumar43@gmail.com','9852345745','5'),
('Vijay Kumar', 'vijaykumar43@gmail.com','9898775745','6'),
('Rahul Kumar', 'rahulkumar43@gmail.com','9854675745','9')
select * from Customers