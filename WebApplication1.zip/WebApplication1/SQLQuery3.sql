﻿create table Employee(Id int primary key identity, Name varchar(56), Gender varchar(10),Mobile varchar(15),
Email varchar(58), Address varchar(78))