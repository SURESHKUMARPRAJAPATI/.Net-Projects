﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class CustomerController : Controller
    {
        private ApplicationDbContext dbContext;
        public CustomerController(ApplicationDbContext dbContext)
        {
           this.dbContext = dbContext;
        }
        public IActionResult Index()
        {
            List<Location>
            Locations = dbContext.Locations.ToList();
        
            return View(Locations);
        }
        public IActionResult Customer(int Id)
        {
            List<Customer>
                Customer=dbContext.Customers.Where(e=>e.Location.Id==Id).ToList();
            return View(Customer);
        }
    }
}
