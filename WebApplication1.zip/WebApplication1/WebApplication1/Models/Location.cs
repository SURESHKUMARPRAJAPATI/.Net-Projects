﻿namespace WebApplication1.Models
{
    public class Location
    { 
        public int Id { get; set; } 
    public string Place { get; set; }
    public string Details { get; set; }

    
    }
}
