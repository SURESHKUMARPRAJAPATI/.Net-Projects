﻿using Microsoft.AspNetCore.Mvc;
using Student_mvc_Project.Models;
using System.Collections.Generic;
using System.Linq;

namespace Student_mvc_Project.Controllers
{
    public class StudentController : Controller
    {
        private ApplicationDbContext dbContext;
        public StudentController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public IActionResult Index()
        {
            List<Student>
                stu = dbContext.Student.ToList();
            return View(stu);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student stu)
        {
            if (ModelState.IsValid)
            {
                dbContext.Student.Add(stu);
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(stu);
            }
        }
        public IActionResult Delete(int Id)
        {
            var stu = dbContext.Student.SingleOrDefault(x => x.Id == Id);
            if (stu != null)
            {
                dbContext.Student.Remove(stu);
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
        public IActionResult Edit (int Id)
        {
            var stu = dbContext.Student.SingleOrDefault(x => x.Id == Id);

            return View(stu);
        }
        [HttpPost]
        public IActionResult Edit(Student stu)
        {
            dbContext.Student.Update(stu);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
