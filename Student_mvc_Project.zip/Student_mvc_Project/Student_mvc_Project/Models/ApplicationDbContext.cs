﻿using Microsoft.EntityFrameworkCore;
namespace Student_mvc_Project.Models
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext>
            options) : base(options) { }
        
            public DbSet<Student> Student { get; set; }
        }
    }

