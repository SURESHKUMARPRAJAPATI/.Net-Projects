﻿using Microsoft.EntityFrameworkCore;

namespace Suresh_Mvc_Project.Models
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext>options
            ) : base(options){ }
        public DbSet<Location> Locations { get; set; }
        public DbSet<Customer> customers { get; set; }


    }
}
