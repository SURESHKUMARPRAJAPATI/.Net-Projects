﻿using Microsoft.AspNetCore.Mvc;
using Suresh_Mvc_Project.Models;
using System.Collections.Generic;
using System.Linq;

namespace Suresh_Mvc_Project.Controllers
{
    public class CustomerController : Controller
    {
        private ApplicationDbContext dbContext;
        public CustomerController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;

        }
        public IActionResult Index()
        {
            List<Location> locations =
                dbContext.Locations.ToList();
            return View(locations);
        }
        public IActionResult Customer(int id)
        {
            List<Customer>
                Customers = dbContext.customers.Where(e => e.Location.Id == id).ToList();
            return View(Customers);
        }
    }
}
